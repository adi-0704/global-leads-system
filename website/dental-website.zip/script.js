/* ================================================================
   Smile Dental Care — Interactions
   ================================================================ */

/* ── Navbar shadow on scroll ── */
const navbar = document.getElementById('navbar');
window.addEventListener('scroll', () => {
  navbar.classList.toggle('scrolled', window.scrollY > 10);
});

/* ── Mobile menu ── */
const hamburger = document.getElementById('hamburger');
const mobileNav = document.getElementById('mobileNav');
hamburger.addEventListener('click', () => {
  const open = mobileNav.classList.toggle('open');
  hamburger.setAttribute('aria-expanded', open);
  hamburger.textContent = open ? '✕' : '☰';
});
function closeMobile() {
  mobileNav.classList.remove('open');
  hamburger.setAttribute('aria-expanded', 'false');
  hamburger.textContent = '☰';
}

/* ── Reveal on scroll ── */
const revealObserver = new IntersectionObserver((entries) => {
  entries.forEach((entry) => {
    if (entry.isIntersecting) {
      entry.target.classList.add('in');
      revealObserver.unobserve(entry.target);
    }
  });
}, { threshold: 0.12, rootMargin: '0px 0px -40px 0px' });

document.querySelectorAll('.reveal').forEach((el, i) => {
  el.style.transitionDelay = `${(i % 3) * 90}ms`;
  revealObserver.observe(el);
});

/* ── Count-up stats ── */
function animateCount(el) {
  const target = +el.dataset.target;
  const duration = 1600;
  const start = performance.now();
  function tick(now) {
    const p = Math.min((now - start) / duration, 1);
    const eased = 1 - Math.pow(1 - p, 3);
    const val = Math.floor(eased * target);
    el.textContent = val >= 1000 ? val.toLocaleString('en-IN') : val;
    if (p < 1) requestAnimationFrame(tick);
    else el.textContent = target >= 1000 ? target.toLocaleString('en-IN') : target;
  }
  requestAnimationFrame(tick);
}
const statObserver = new IntersectionObserver((entries) => {
  entries.forEach((entry) => {
    if (entry.isIntersecting) {
      animateCount(entry.target);
      statObserver.unobserve(entry.target);
    }
  });
}, { threshold: 0.6 });
document.querySelectorAll('.stat-n').forEach((el) => statObserver.observe(el));

/* ── Booking form ── */
function handleBooking(e) {
  e.preventDefault();
  const btn = document.getElementById('bookBtn');
  btn.textContent = 'Sending…';
  btn.disabled = true;
  setTimeout(() => {
    document.getElementById('bookForm').classList.add('hidden');
    document.getElementById('bookSuccess').classList.remove('hidden');
  }, 900);
}

/* ── Set min date on the date picker to today ── */
const dateInput = document.querySelector('#bookForm input[type="date"]');
if (dateInput) dateInput.min = new Date().toISOString().split('T')[0];
